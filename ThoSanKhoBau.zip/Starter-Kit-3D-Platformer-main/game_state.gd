extends Node

var selected_character = "A"

var current_level := 1

var final_time: float = 0.0
