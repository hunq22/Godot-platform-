extends Node3D

@export var move_distance: float = 3.0
@export var move_speed: float = 2.0
@export_enum("X", "Y") var move_axis = "Y"

var start_position: Vector3
var time := 0.0


func _ready():
	start_position = position


func _physics_process(delta):
	time += delta * move_speed

	var offset = sin(time) * move_distance

	if move_axis == "Y":
		position = start_position + Vector3(0, offset, 0)
	else:
		position = start_position + Vector3(offset, 0, 0)
