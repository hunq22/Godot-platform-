extends Control

var next_button: Button
var exit_button: Button
var time_label: Label
var title: Label


func _ready():

	next_button = find_child("NextButton", true, false)
	exit_button = find_child("ExitButton", true, false)
	time_label = find_child("TimeLabel", true, false)
	title = find_child("Title", true, false)

	if title != null:
		title.text = "LEVEL %d COMPLETE!" % GameState.current_level

	if time_label != null:
		time_label.text = "Time: " + format_time(GameState.final_time)

	if next_button != null:
		next_button.pressed.connect(_on_next_pressed)

	if exit_button != null:
		exit_button.pressed.connect(_on_exit_pressed)


func format_time(time: float) -> String:

	var total_seconds = int(time)
	var minutes = total_seconds / 60
	var seconds = total_seconds % 60
	var centiseconds = int((time - total_seconds) * 100)

	return "%d:%02d:%02d" % [
		minutes,
		seconds,
		centiseconds
	]


func _on_next_pressed():

	if GameState.current_level == 1:

		GameState.current_level = 2

		get_tree().change_scene_to_file(
			"res://level_2.tscn"
		)

	elif GameState.current_level == 2:

		GameState.current_level = 3

		get_tree().change_scene_to_file(
			"res://level_3.tscn"
		)


func _on_exit_pressed():

	get_tree().quit()
