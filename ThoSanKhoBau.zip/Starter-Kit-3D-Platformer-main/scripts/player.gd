extends CharacterBody3D

signal coin_collected

@export_subgroup("Components")
@export var view: Node3D

@export_subgroup("Properties")
@export var movement_speed = 250
@export var jump_strength = 7

var movement_velocity: Vector3
var rotation_direction: float
var gravity = 0.0

var jump_single = true
var jump_double = true

var coins = 0
var time_passed := 0.0
var level_ending := false

var start_position: Vector3

var character_scale := Vector3(0.5, 0.5, 0.5)

@onready var model = $Character
@onready var character_a = get_node("Character/character-a")
@onready var character_b = get_node("Character/character-b")
@onready var character_c = get_node("Character/character-c")
@onready var character_d = get_node("Character/character-d")

@onready var particles_trail = $ParticlesTrail
@onready var sound_footsteps = $SoundFootsteps

@onready var timer_label = get_node("../HUD/TimerLabel")
@onready var coins_label = get_node("../HUD/Coins")


func _ready():
	start_position = global_position

	model.scale = character_scale

	load_character()

	coins = 0
	coins_label.text = "0/14"

	time_passed = 0.0
	timer_label.text = "0:00:00"


func load_character():
	var selected = GameState.selected_character

	character_a.visible = false
	character_b.visible = false
	character_c.visible = false
	character_d.visible = false

	match selected:
		"A":
			character_a.visible = true
		"B":
			character_b.visible = true
		"C":
			character_c.visible = true
		"D":
			character_d.visible = true
		_:
			character_a.visible = true

	print("Loaded character: ", selected)


func _unhandled_input(event):
	if event is InputEventKey:
		if event.pressed and event.keycode == KEY_ESCAPE:
			get_tree().quit()


func _physics_process(delta):

	# TIMER
	time_passed += delta

	var total_seconds = int(time_passed)
	var minutes = total_seconds / 60
	var seconds = total_seconds % 60
	var centiseconds = int((time_passed - total_seconds) * 100)

	timer_label.text = "%d:%02d:%02d" % [
		minutes,
		seconds,
		centiseconds
	]

	# MOVEMENT
	handle_controls(delta)

	handle_gravity(delta)

	handle_effects(delta)

	var applied_velocity: Vector3

	applied_velocity = velocity.lerp(
		movement_velocity,
		delta * 10
	)

	applied_velocity.y = -gravity

	velocity = applied_velocity

	move_and_slide()

	# ROTATION
	if Vector2(velocity.z, velocity.x).length() > 0:
		rotation_direction = Vector2(
			velocity.z,
			velocity.x
		).angle()

	rotation.y = lerp_angle(
		rotation.y,
		rotation_direction,
		delta * 10
	)

	# FALL OFF MAP
	if position.y < -10:
		die()

	model.scale = character_scale


func handle_controls(delta):

	var input := Vector3.ZERO

	input.x = Input.get_axis(
		"move_left",
		"move_right"
	)

	input.z = Input.get_axis(
		"move_forward",
		"move_back"
	)

	input = input.rotated(
		Vector3.UP,
		view.rotation.y
	)

	if input.length() > 1:
		input = input.normalized()

	movement_velocity = input * movement_speed * delta

	if Input.is_action_just_pressed("jump"):
		if jump_single or jump_double:
			jump()


func handle_gravity(delta):

	gravity += 25 * delta

	if gravity > 0 and is_on_floor():
		jump_single = true
		gravity = 0


func jump():

	gravity = -jump_strength

	model.scale = character_scale

	if jump_single:
		jump_single = false
		jump_double = true
	else:
		jump_double = false


func handle_effects(delta):

	particles_trail.emitting = false
	sound_footsteps.stream_paused = true

	if is_on_floor():

		var horizontal_velocity = Vector2(
			velocity.x,
			velocity.z
		)

		var speed_factor = (
			horizontal_velocity.length()
			/ movement_speed
			/ delta
		)

		if speed_factor > 0.3:
			sound_footsteps.stream_paused = false
			sound_footsteps.pitch_scale = speed_factor

		if speed_factor > 0.75:
			particles_trail.emitting = true


# =========================
# SPIKE / DEATH
# =========================

func die():

	print("Player hit spike!")

	global_position = start_position

	velocity = Vector3.ZERO

	gravity = 0

	jump_single = true
	jump_double = true


# =========================
# COINS
# =========================

func collect_coin():

	if level_ending:
		return

	coins += 1

	coins_label.text = "%d/14" % coins

	coin_collected.emit(coins)

	print("Coins: ", coins)

	if coins >= 14:

		level_ending = true

		end_level()


# =========================
# LEVEL COMPLETE
# =========================

func end_level():

	GameState.final_time = time_passed

	print(
		"LEVEL ",
		GameState.current_level,
		" COMPLETE!"
	)

	get_tree().call_deferred(
		"change_scene_to_file",
		"res://level_complete.tscn"
	)
