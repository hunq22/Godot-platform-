extends Control

var selected_character = "A"

@onready var character_option = $CenterContainer/VBoxContainer/CharacterOption
@onready var play_button = $CenterContainer/VBoxContainer/PlayButton
@onready var exit_button = $CenterContainer/VBoxContainer/ExitButton


func _ready():
	character_option.clear()

	character_option.add_item("Character A")
	character_option.add_item("Character B")
	character_option.add_item("Character C")
	character_option.add_item("Character D")

	character_option.item_selected.connect(_on_character_selected)
	play_button.pressed.connect(_on_play_pressed)
	exit_button.pressed.connect(_on_exit_pressed)


func _on_character_selected(index):
	selected_character = char(65 + index)

	GameState.selected_character = selected_character

	print("Selected Character: " + selected_character)


func _on_play_pressed():
	print("PLAY BUTTON CLICKED")
	print("Selected Character: " + GameState.selected_character)

	get_tree().change_scene_to_file("res://scenes/main.tscn")


func _on_exit_pressed():
	print("EXIT BUTTON CLICKED")
	get_tree().quit()
